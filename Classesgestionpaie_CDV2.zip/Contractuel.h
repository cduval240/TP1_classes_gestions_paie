#ifndef __CONTRACTUEL_H__
#define __CONTRACTUEL_H__

#include <iostream>
#include <string>
#include "Employe.h"

class Contractuel: public Employe {

  protected:
    int montant;
    int nb_semaines;

  public:
    Contractuel(std::string le_nom, int le_matricule, int le_montant, int le_nb_semaines);

    ~Contractuel(){std::cout<< "Contractuel detruit"<<std::endl;}

    double calculPaieBrute();
  
};

#endif // __CONTRACTUEL_H__