#include <iostream>
#include "Employe.h"
#include "Contractuel.h"
#include "Ponctuel.h"
#include "Syndique.h"

int AppelMenu();

int main() {
  // Tableau des employes
    Employe* nos_employes[250];

int choix=0;
int compteur=0;
//Employe
std::string nom;
int matricule;
//syndique
double salaire_horaire;
double heures;
//contractuel
int montant;
int nb_semaines;
//Ponctuel
double montant_unique;

double paieTotale=0;
double impotQCTotal=0;
double impotCATotal=0;
//menu
  do{
    choix=AppelMenu();

    switch (choix) {
      case 1:
      //syndique
        std::cout<<"Entrez le nom de famille: "<<std::endl;
        std::cin>>nom;
        std::cout<<"Entrez le matricule: "<<std::endl;
        std::cin>>matricule;
        std::cout<<"Entrez le nombre d'heures travaillées dans la semaine: "<<std::endl;
        std::cin>>heures;
        std::cout<<"Entrez le salaire horaire: "<<std::endl;
        std::cin>>salaire_horaire;
      
        nos_employes[compteur]=new Syndique(nom,matricule,heures,salaire_horaire);
        compteur++;
    
        break;
      case 2:
      //contractuel
        std::cout<<"Entrez le nom de famille: "<<std::endl;
        std::cin>>nom;
        std::cout<<"Entrez le matricule: "<<std::endl;
        std::cin>>matricule;
        std::cout<<"Entrez le montant du contrat: "<<std::endl;
        std::cin>>montant;
        std::cout<<"Entrez la durée du contrat en semaines: "<<std::endl;
        std::cin>>nb_semaines;

        nos_employes[compteur]=new Contractuel(nom,matricule,montant,nb_semaines);
        compteur++;

        break;
      case 3:
      //Ponctuel
        std::cout<<"Entrez le nom de famille: "<<std::endl;
        std::cin>>nom;
        std::cout<<"Entrez le matricule: "<<std::endl;
        std::cin>>matricule;
        std::cout<<"Entrez le montant unique: "<<std::endl;
        std::cin>>montant_unique;

        nos_employes[compteur]=new Ponctuel(nom,matricule,montant_unique);
        compteur++;
        break;
      case 4:
      //affichage de chaque employe
        for(int i=0;i<compteur; i++){
          nos_employes[i]->AfficherPaie();
        }
       //calcul de la paie totale
        for(int i=0;i<compteur;i++){
          paieTotale+=nos_employes[i]->calculPaieBrute();
          impotCATotal=0.15*paieTotale;
          impotQCTotal=0.15*paieTotale;
        }
        //affichage totaux
        std::cout<<"Totaux"<<std::endl;
        std::cout<<"Montants totaux versés de "<<paieTotale<<"$"<<std::endl;
        std::cout<<"Impôts à transférer CA de "<<impotCATotal<<"$"<<std::endl;
        std::cout<<"Impôts à transférer QC de "<<impotQCTotal<<"$"<<std::endl;
        break;
      case 5:
        std::cout << "Au revoir !" << std::endl;
        break;
      default:
        std::cout << "Choix invalide !" << std::endl;
    };

  }while (choix != 5);

  for(int i=0;i<compteur;i++){
    delete nos_employes[i];
  }

}

int AppelMenu(){
  int choix = 0;
    std::cout << "=== MENU ===" << std::endl;
    std::cout << "1. Ajouter un(e) employé(e) syndiqué(e)" << std::endl;
    std::cout << "2. Ajouter un(e) employé(e) contractuel(le)" << std::endl;
    std::cout << "3. Ajouter un(e) employé(e) ponctuel(le)" << std::endl;
    std::cout << "4. Afficher le résultat de la paie pour les employés entrés" << std::endl;
    std::cout << "5. Quitter" << std::endl;

    std::cout << std::endl << "Choix : ";
      std::cin >> choix;
      return choix;
}


