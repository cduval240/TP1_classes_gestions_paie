#include "Syndique.h"

Syndique::Syndique(std::string le_nom, int le_matricule, double les_heures, double le_salaire_horaire):Employe(le_nom,le_matricule) {

  this->heures = les_heures;
  this->salaire_horaire = le_salaire_horaire;
}

double Syndique::calculPaieBrute(){

  double paieBrute=this->salaire_horaire*heures;
  return paieBrute;
}