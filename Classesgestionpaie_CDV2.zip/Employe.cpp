#include "Employe.h"

Employe::Employe(std::string le_nom, int le_matricule) {
  this->nom = le_nom;
  this->matricule=le_matricule;
}

std::string Employe::getNom() {
  return this->nom;
}

int Employe::getMatricule(){
  return this->matricule;
}


void Employe::AfficherPaie(){
 std::cout << this->getNom()<< "  "<< this->getMatricule()<<std::endl;
 std::cout <<"Paie brute de "<< this->calculPaieBrute()<< "$"<<std::endl;
 std::cout <<"Impots de CA de "<<this->calculPaieBrute()*0.15<< "$"<<std::endl;
 std::cout << "Impot de QC de " <<this->calculPaieBrute()*0.15 <<"$"<<std::endl;
 std::cout<< "Paie nette de "<<this->calculPaieBrute()*0.6<< "$"<<std::endl;
}

