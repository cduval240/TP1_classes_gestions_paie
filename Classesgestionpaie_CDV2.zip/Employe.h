#ifndef __EMPLOYE_H__
#define __EMPLOYE_H__

#include <iostream>
#include <string>

class Employe {
  private:
    std::string nom;
    int matricule;
  public:
    Employe(std::string le_nom, int le_matricule);
     virtual ~Employe() {std::cout << "Employe detruit" <<std::endl;}

    std::string getNom();
    int getMatricule();
    
    virtual double calculPaieBrute()=0;
    virtual void AfficherPaie();

};

#endif // __EMPLOYE_H__