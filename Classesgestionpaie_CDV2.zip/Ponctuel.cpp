#include "Ponctuel.h"

Ponctuel::Ponctuel(std::string le_nom, int le_matricule, double le_montant_unique):Employe(le_nom,le_matricule) {

  this->montant_unique = le_montant_unique;
}

double Ponctuel::calculPaieBrute(){

  double paieBrute=this->montant_unique;
  return paieBrute;
}