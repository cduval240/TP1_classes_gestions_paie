#ifndef __SYNDIQUE_H__
#define __SYNDIQUE_H__

#include <iostream>
#include <string>
#include "Employe.h"

class Syndique: public Employe {

  protected:
    double heures;
    double salaire_horaire;

  public:
    Syndique(std::string le_nom, int le_matricule, double les_heures, double le_salaire_horaire);

    ~Syndique(){std::cout<< "Syndique detruit"<<std::endl;}

    double calculPaieBrute();
  
};

#endif // __SYNDIQUE_H__