#ifndef __PONCTUEL_H__
#define __PONCTUEL_H__

#include <iostream>
#include <string>
#include "Employe.h"

class Ponctuel: public Employe {

  protected:
    double montant_unique;
  
  public:
    Ponctuel(std::string le_nom, int le_matricule, double le_montant_unique);

    ~Ponctuel(){std::cout<< "Ponctuel detruit"<<std::endl;}

    double calculPaieBrute();
  
};

#endif // __PONCTUEL_H__