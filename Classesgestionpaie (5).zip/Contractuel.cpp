#include "Contractuel.h"

Contractuel::Contractuel(std::string le_nom, int le_matricule, int le_montant, int le_nb_semaines):Employe(le_nom,le_matricule) {

  this->montant = le_montant;
  this->nb_semaines = le_nb_semaines;
}

double Contractuel::calculPaieBrute(){

  double paieBrute=this->montant/this->nb_semaines;
  return paieBrute;
}